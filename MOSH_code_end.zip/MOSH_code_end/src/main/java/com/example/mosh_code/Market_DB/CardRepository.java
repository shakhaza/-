package com.example.mosh_code.Market_DB;

import java.sql.*;

public class CardRepository {

    public static final long DEMO_BALANCE = 1_000_000;

    /** Ensures a card exists for user; returns card id. */
    public long ensureCard(long userId) {
        try (Connection c = DBManager.getConnection()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT id FROM cards WHERE user_id = ? LIMIT 1"
            )) {
                ps.setLong(1, userId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) return rs.getLong(1);
            }

            String cardNumber = "KZ" + (1000_0000_0000L + (System.currentTimeMillis() % 9000_0000_0000L));

            try (PreparedStatement ins = c.prepareStatement(
                    "INSERT INTO cards(user_id, card_number, balance) VALUES(?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS
            )) {
                ins.setLong(1, userId);
                ins.setString(2, cardNumber);
                ins.setLong(3, DEMO_BALANCE);
                ins.executeUpdate();
                ResultSet keys = ins.getGeneratedKeys();
                if (keys.next()) return keys.getLong(1);
            }

            throw new SQLException("Failed to create card");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public long getBalanceByUser(long userId) {
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT balance FROM cards WHERE user_id = ? LIMIT 1")) {
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getLong(1);
            return 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public String getCardNumberByUser(long userId) {
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT card_number FROM cards WHERE user_id = ? LIMIT 1")) {
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString(1);
            return "";
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void updateBalanceByUser(Connection tx, long userId, long newBalance) throws SQLException {
        try (PreparedStatement ps = tx.prepareStatement("UPDATE cards SET balance = ? WHERE user_id = ?")) {
            ps.setLong(1, newBalance);
            ps.setLong(2, userId);
            ps.executeUpdate();
        }
    }
}
