package com.example.mosh_code.Market_DB;

import com.example.mosh_code.Market_Model.Favorite;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FavoriteRepository {

    public long addToFavorites(Connection tx, int productId, long userId) throws SQLException {
        try (PreparedStatement check = tx.prepareStatement(
                "SELECT id FROM favorites WHERE product_id = ? AND user_id = ? LIMIT 1")) {
            check.setInt(1, productId);
            check.setLong(2, userId);
            ResultSet rs = check.executeQuery();
            if (rs.next()) return rs.getLong(1);
        }

        try (PreparedStatement ps = tx.prepareStatement(
                "INSERT INTO favorites(product_id, user_id) VALUES(?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, productId);
            ps.setLong(2, userId);
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) return keys.getLong(1);
            throw new SQLException("Failed to add to favorites");
        }
    }

    public void removeFromFavorites(Connection tx, int productId, long userId) throws SQLException {
        try (PreparedStatement ps = tx.prepareStatement(
                "DELETE FROM favorites WHERE product_id = ? AND user_id = ?")) {
            ps.setInt(1, productId);
            ps.setLong(2, userId);
            ps.executeUpdate();
        }
    }

    public List<Favorite> getUserFavorites(long userId) {
        List<Favorite> favorites = new ArrayList<>();
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT id, product_id, user_id, added_at FROM favorites WHERE user_id = ? ORDER BY added_at DESC")) {
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Favorite fav = new Favorite(
                        rs.getLong(1),
                        rs.getInt(2),
                        rs.getLong(3),
                        rs.getTimestamp(4).toLocalDateTime()
                );
                favorites.add(fav);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return favorites;
    }

    public boolean isFavorite(int productId, long userId) {
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT id FROM favorites WHERE product_id = ? AND user_id = ? LIMIT 1")) {
            ps.setInt(1, productId);
            ps.setLong(2, userId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

