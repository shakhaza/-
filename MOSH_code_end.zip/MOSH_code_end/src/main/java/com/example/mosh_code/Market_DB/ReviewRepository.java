package com.example.mosh_code.Market_DB;

import com.example.mosh_code.Market_Model.Review;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class ReviewRepository {
    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    public long createReview(Connection tx, int productId, long userId, String userName, int rating, String comment) throws SQLException {
        try (PreparedStatement ps = tx.prepareStatement(
                "INSERT INTO reviews(product_id, user_id, user_name, rating, comment, created_at) VALUES(?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, productId);
            ps.setLong(2, userId);
            ps.setString(3, userName);
            ps.setInt(4, rating);
            ps.setString(5, comment);
            ps.setString(6, LocalDateTime.now().format(ISO));
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) return keys.getLong(1);
            throw new SQLException("Failed to create review");
        }
    }

    public List<Review> getProductReviews(int productId) {
        List<Review> reviews = new ArrayList<>();
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT id, product_id, user_id, user_name, rating, comment, created_at FROM reviews WHERE product_id = ? ORDER BY created_at DESC")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Review review = new Review(
                        rs.getLong(1),
                        rs.getInt(2),
                        rs.getLong(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getString(6),
                        LocalDateTime.parse(rs.getString(7), ISO)
                );
                reviews.add(review);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return reviews;
    }

    public double getAverageRating(int productId) {
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT AVG(rating) FROM reviews WHERE product_id = ?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                double avg = rs.getDouble(1);
                return Double.isNaN(avg) ? 0 : avg;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }

    public int getReviewCount(int productId) {
        try (Connection c = DBManager.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT COUNT(*) FROM reviews WHERE product_id = ?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return 0;
    }
}


