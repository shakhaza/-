package com.example.mosh_code.Market_DB;

import com.example.mosh_code.Market_DB.DB;

import java.sql.Connection;
import java.sql.SQLException;

public class TestDB {
    public static void main(String[] args) throws Exception {
        try (Connection e = DB.getConnection()) {
            System.out.println(" CONNECTED TO: " + e.getMetaData().getURL());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}