package com.example.mosh_code.Market_Model;

public class CartItem {
    private final Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        if (product == null) {
            throw new IllegalArgumentException("Product null болмауы керек");
        }
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity кем дегенде 1 болуы керек");
        }
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity кем дегенде 1 болуы керек");
        }
        this.quantity = quantity;
    }

    public void addQuantity(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount > 0 болуы керек");
        }
        this.quantity += amount;
    }

    public void removeQuantity(int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount > 0 болуы керек");
        }
        int newQty = this.quantity - amount;
        if (newQty <= 0) {
            throw new IllegalArgumentException("Quantity 0-ден төмен түсіп кетті");
        }
        this.quantity = newQty;
    }

    public int getTotalPrice() {
        return product.getPrice() * quantity;
    }
}