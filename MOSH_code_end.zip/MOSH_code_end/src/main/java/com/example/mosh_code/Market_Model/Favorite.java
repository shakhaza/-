package com.example.mosh_code.Market_Model;

import java.time.LocalDateTime;

public class Favorite {
    private long id;
    private int productId;
    private long userId;
    private LocalDateTime addedAt;

    public Favorite(long id, int productId, long userId, LocalDateTime addedAt) {
        this.id = id;
        this.productId = productId;
        this.userId = userId;
        this.addedAt = addedAt;
    }

    public Favorite(int productId, long userId) {
        this(-1, productId, userId, LocalDateTime.now());
    }

    public long getId() {
        return id;
    }

    public int getProductId() {
        return productId;
    }

    public long getUserId() {
        return userId;
    }

    public LocalDateTime getAddedAt() {
        return addedAt;
    }

    public void setId(long id) {
        this.id = id;
    }
}

