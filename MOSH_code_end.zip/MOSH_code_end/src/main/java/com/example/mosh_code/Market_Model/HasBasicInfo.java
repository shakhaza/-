package com.example.mosh_code.Market_Model;

public interface HasBasicInfo {
    int getId();
    String getName();
    int getPrice();
    String getDescription();
    String getImagePath();
}

