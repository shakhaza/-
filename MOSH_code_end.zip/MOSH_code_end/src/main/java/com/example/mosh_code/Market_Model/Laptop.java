package com.example.mosh_code.Market_Model;

public class Laptop extends Product implements LaptopSpecs {
    private final String model;
    private final String cpu;
    private final int ramGB;
    private final int ssdGB;
    private final double screenInches;
    private final String os;
    private final int weightGrams;

    public Laptop(int id,
                  String name,
                  int price,
                  String description,
                  String imagePath,
                  Product_Category category,
                  String model,
                  String cpu,
                  int ramGB,
                  int ssdGB,
                  double screenInches,
                  String os,
                  int weightGrams) {

        super(id, name, price, description, imagePath, category);
        this.model = model;
        this.cpu = cpu;
        this.ramGB = ramGB;
        this.ssdGB = ssdGB;
        this.screenInches = screenInches;
        this.os = os;
        this.weightGrams = weightGrams;
    }

    @Override public String getModel() { return model; }
    @Override public String getCpu() { return cpu; }
    @Override public int getRamGB() { return ramGB; }
    @Override public int getSsdGB() { return ssdGB; }
    @Override public double getScreenInches() { return screenInches; }
    @Override public String getOs() { return os; }

    public int getWeightGrams() { return weightGrams; }
}


