package com.example.mosh_code.Market_Model;

public interface LaptopSpecs {
    String getModel();
    String getCpu();

    int getRamGB();
    int getSsdGB();

    double getScreenInches();
    String getOs();
}
