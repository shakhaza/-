package com.example.mosh_code.Market_Model;

public class Product_Category {
    public static final Product_Category Smartphone = new Product_Category(1, "Smartphone");
    public static final Product_Category Laptop = new Product_Category(2, "Laptop");

    private int id;
    private String name;

    public Product_Category(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Product_Category)) return false;
        Product_Category other = (Product_Category) obj;
        return this.id == other.id && this.name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(id, name);
    }
}
