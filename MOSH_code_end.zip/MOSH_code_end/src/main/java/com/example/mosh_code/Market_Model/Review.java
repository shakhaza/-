package com.example.mosh_code.Market_Model;

import java.time.LocalDateTime;

public class Review {
    private long id;
    private int productId;
    private long userId;
    private String userName;
    private int rating;
    private String comment;
    private LocalDateTime createdAt;

    public Review(long id, int productId, long userId, String userName, int rating, String comment, LocalDateTime createdAt) {
        this.id = id;
        this.productId = productId;
        this.userId = userId;
        this.userName = userName;
        this.rating = rating;
        this.comment = comment;
        this.createdAt = createdAt;
    }

    public Review(int productId, long userId, String userName, int rating, String comment) {
        this(-1, productId, userId, userName, rating, comment, LocalDateTime.now());
    }

    public long getId() {
        return id;
    }

    public int getProductId() {
        return productId;
    }

    public long getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public int getRating() {
        return rating;
    }

    public String getComment() {
        return comment;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}

