package com.example.mosh_code.Market_Service;

import com.example.mosh_code.Market_DB.CardRepository;
import com.example.mosh_code.Market_DB.UserRepository;

/** Creates demo user + card, provides balance. */
public class AccountService {

    private final UserRepository userRepo = new UserRepository();
    private final CardRepository cardRepo = new CardRepository();

    public long initDemoAccount() {
        long userId = userRepo.ensureDemoUser();
        cardRepo.ensureCard(userId);
        return userId;
    }

    public long getBalance(long userId) {
        return cardRepo.getBalanceByUser(userId);
    }

    public String getCardNumber(long userId) {
        return cardRepo.getCardNumberByUser(userId);
    }
}
