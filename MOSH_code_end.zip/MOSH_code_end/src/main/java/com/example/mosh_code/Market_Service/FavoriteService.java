package com.example.mosh_code.Market_Service;

import com.example.mosh_code.Market_DB.DBManager;
import com.example.mosh_code.Market_DB.FavoriteRepository;
import com.example.mosh_code.Market_Model.Favorite;
import java.sql.Connection;
import java.util.List;

public class FavoriteService {
    private final FavoriteRepository favoriteRepository = new FavoriteRepository();

    public void toggleFavorite(int productId, long userId) {
        try (Connection c = DBManager.getConnection()) {
            c.setAutoCommit(false);
            try {
                if (favoriteRepository.isFavorite(productId, userId)) {
                    favoriteRepository.removeFromFavorites(c, productId, userId);
                } else {
                    favoriteRepository.addToFavorites(c, productId, userId);
                }
                c.commit();
            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        } catch (Exception e) {
            throw new RuntimeException("Избранное өзгерту сәтсіз болды", e);
        }
    }

    public List<Favorite> getUserFavorites(long userId) {
        return favoriteRepository.getUserFavorites(userId);
    }

    public boolean isFavorite(int productId, long userId) {
        return favoriteRepository.isFavorite(productId, userId);
    }
}

