package com.example.mosh_code.Market_Service;

import com.example.mosh_code.Market_DB.DBManager;
import com.example.mosh_code.Market_DB.ReviewRepository;
import com.example.mosh_code.Market_Model.Review;
import java.sql.Connection;
import java.util.List;

public class ReviewService {
    private final ReviewRepository reviewRepository = new ReviewRepository();

    public void addReview(int productId, long userId, String userName, int rating, String comment) {
        try (Connection c = DBManager.getConnection()) {
            c.setAutoCommit(false);
            try {
                reviewRepository.createReview(c, productId, userId, userName, rating, comment);
                c.commit();
            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        } catch (Exception e) {
            throw new RuntimeException("Отзыв қосу сәтсіз болды", e);
        }
    }

    public List<Review> getReviews(int productId) {
        return reviewRepository.getProductReviews(productId);
    }

    public double getAverageRating(int productId) {
        return reviewRepository.getAverageRating(productId);
    }

    public int getReviewCount(int productId) {
        return reviewRepository.getReviewCount(productId);
    }
}


