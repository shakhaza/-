package com.example.mosh_code.Market_UI.app;

import com.example.mosh_code.Market_Service.CartService;
import com.example.mosh_code.Market_Service.AccountService;
import com.example.mosh_code.Market_Service.OrderService;
import com.example.mosh_code.Market_Service.ShopService;
import com.example.mosh_code.Market_DB.DBManager;

public class AppContext {
    public final ShopService shopService = new ShopService();
    public final CartService cartService = new CartService();
    public final AccountService accountService = new AccountService();
    public final OrderService orderService = new OrderService();

    public User currentUser;

    // ★ ЕДИНСТВЕННЫЙ конструктор - БЕЗ ПАРАМЕТРОВ
    public AppContext() {
        DBManager.initSchema();
        long userId = accountService.initDemoAccount();
        this.currentUser = new User(userId, "Demo User");
    }

    // Простой класс User для хранения информации о текущем пользователе
    public static class User {
        private long id;
        private String name;

        public User(long id, String name) {
            this.id = id;
            this.name = name;
        }

        public long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }
}


