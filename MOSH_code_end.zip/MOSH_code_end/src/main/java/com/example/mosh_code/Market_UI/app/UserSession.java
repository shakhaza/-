package com.example.mosh_code.Market_UI;

public class UserSession {
    private long id;
    private String fullName;

    public UserSession(long id, String fullName) {
        this.id = id;
        this.fullName = fullName;
    }

    public long getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}

