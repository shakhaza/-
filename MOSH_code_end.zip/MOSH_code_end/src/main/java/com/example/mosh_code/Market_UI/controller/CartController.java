package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_Model.CartItem;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

public class CartController {
    @FXML private ListView<String> cartList;
    @FXML private Label totalLabel;

    private AppContext ctx;

    public void setContext(AppContext ctx) {
        this.ctx = ctx;

        // Double click -> remove selected item
        cartList.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) removeSelected();
        });

        refresh();
    }

    public void refresh() {
        cartList.getItems().clear();

        for (CartItem ci : ctx.cartService.getItems()) {
            String line = ci.getProduct().getId() + " | " +
                    ci.getProduct().getName() + " x" + ci.getQuantity() +
                    " — " + (int) ci.getTotalPrice() + " ₸";
            cartList.getItems().add(line);
        }

        totalLabel.setText("Total: " + (int) ctx.cartService.getTotal() + " ₸");
    }

    private void removeSelected() {
        String selected = cartList.getSelectionModel().getSelectedItem();
        if (selected == null) return;

        // format: "ID | name xQ — total ₸"
        String idStr = selected.split("\\|")[0].trim();
        int id = Integer.parseInt(idStr);

        ctx.cartService.removeByProductId(id);
        refresh();
    }

    public void clear() {
        ctx.cartService.clear();
        refresh();
    }
}

