package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_Model.CartItem;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class CheckoutController implements UsesContext {
    @FXML
    private Label totalLabel;
    @FXML
    private Label balanceLabel;
    @FXML
    private Label statusLabel;
    @FXML
    private TextArea addressArea;
    @FXML
    private Button checkoutButton;

    private AppContext ctx;
    private Runnable onSuccess;

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        refresh();
    }

    @FXML
    public void refresh() {
        if (ctx == null || ctx.currentUser == null) {
            return;
        }

        long userId = ctx.currentUser.getId();
        long total = (long) ctx.cartService.getTotal();
        long balance = ctx.accountService.getBalance(userId);

        totalLabel.setText("Total: " + total + " ₸");
        balanceLabel.setText("Balance: " + balance + " ₸");
        statusLabel.setText("");
    }

    @FXML
    public void pay() {
        if (ctx == null || ctx.currentUser == null) {
            return;
        }

        try {
            long userId = ctx.currentUser.getId();
            List<CartItem> items = ctx.cartService.getItems();

            if (items.isEmpty()) {
                statusLabel.setText("❌ Себетіңіз бос");
                return;
            }

            long orderId = ctx.orderService.purchaseCart(userId, items);
            ctx.cartService.clear();
            long bal = ctx.accountService.getBalance(userId);

            statusLabel.setText("✅ Төленді! Тапсырыс #" + orderId + ". Жаңа балансы: " + bal + " ₸");
            totalLabel.setText("Total: 0 ₸");
            balanceLabel.setText("Balance: " + bal + " ₸");

            if (onSuccess != null) {
                onSuccess.run();
            }
        } catch (IllegalStateException ex) {
            statusLabel.setText("❌ " + ex.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace();
            statusLabel.setText("❌ Төлеу сәтсіз болды. Консольді тексеріңіз.");
        }
    }

    @FXML
    public void checkout() {
        if (ctx == null || ctx.currentUser == null) {
            showAlert("Қате", "Пайдаланушы табылмады");
            return;
        }

        String address = addressArea != null ? addressArea.getText().trim() : "";
        List<CartItem> items = ctx.cartService.getItems();

        if (items.isEmpty()) {
            showAlert("Қате", "Себетіңіз бос");
            return;
        }

        try {
            long userId = ctx.currentUser.getId();
            long orderId = ctx.orderService.purchaseCart(userId, items);
            ctx.cartService.clear();
            long bal = ctx.accountService.getBalance(userId);

            showSuccess("✓ Тапсырыс орындалды! ID: " + orderId);

            totalLabel.setText("Total: 0 ₸");
            balanceLabel.setText("Balance: " + bal + " ₸");
            statusLabel.setText("✅ Тапсырыс №" + orderId + " сәтті орындалды!");

            if (onSuccess != null) {
                onSuccess.run();
            }
        } catch (Exception e) {
            showAlert("Қате", "Тапсырыс орындау сәтсіз болды: " + e.getMessage());
            statusLabel.setText("❌ " + e.getMessage());
        }
    }

    public void setOnSuccess(Runnable callback) {
        this.onSuccess = callback;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("✓ Сәтті");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
