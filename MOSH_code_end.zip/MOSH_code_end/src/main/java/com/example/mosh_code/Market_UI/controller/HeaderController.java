package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.util.function.Consumer;

public class HeaderController {
    @FXML private TextField searchField;

    private Consumer<String> onSearch;

    public void setContext(AppContext ctx) {
        searchField.setOnAction(e -> {
            if (onSearch != null) onSearch.accept(searchField.getText());
        });
    }

    public void setOnSearch(Consumer<String> onSearch) {
        this.onSearch = onSearch;
    }
}
