package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.StackPane;

import java.io.IOException;

public class MainController {
    @FXML
    private StackPane contentHost;
    @FXML
    private SidebarController sidebarController;
    @FXML
    private HeaderController headerController;

    private AppContext ctx;
    private ProductGridController currentProductGrid;

    @FXML
    public void initialize() {
        // Инициализируем AppContext (конструктор без параметров)
        this.ctx = new AppContext();

        // Настраиваем sidebar
        if (sidebarController != null) {
            sidebarController.setMainController(this);
        }

        // Настраиваем header
        if (headerController != null) {
            headerController.setContext(ctx);
            headerController.setOnSearch(q -> {
                if (currentProductGrid != null) {
                    currentProductGrid.showSearch(q);
                }
            });
        }

        showProducts();
    }

    public void showProducts() {
        loadPage("pages/products.fxml");
    }

    public void showOrders() {
        loadPage("pages/orders.fxml");
    }

    public void showCheckout() {
        loadPage("pages/checkout.fxml");
    }

    public void showProfile() {
        loadPage("pages/profile.fxml");
    }

    public void showProductDetails(ScrollPane detailsPage) {
        if (contentHost != null) {
            contentHost.getChildren().setAll(detailsPage);
        }
    }

    private void loadPage(String fxml) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/mosh_code/view/" + fxml));
            Parent page = loader.load();
            Object controller = loader.getController();

            // Передаем контекст всем контроллерам
            if (controller instanceof UsesContext) {
                ((UsesContext) controller).setContext(ctx);
            }

            // Для ProductGridController - дополнительная конфигурация
            if (controller instanceof ProductGridController) {
                currentProductGrid = (ProductGridController) controller;
                currentProductGrid.setMainController(this);
                System.out.println("ProductGridController loaded");
            } else {
                currentProductGrid = null;
            }

            if (contentHost != null) {
                contentHost.getChildren().setAll(page);
            }
        } catch (IOException e) {
            System.err.println("Error loading page: " + fxml);
            e.printStackTrace();
        }
    }
}

