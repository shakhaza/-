package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_DB.OrderRepository;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;
import java.util.stream.Collectors;

public class OrdersController implements UsesContext {
    @FXML
    private TableView<OrderRepository.OrderRow> ordersTable;
    @FXML
    private TableColumn<OrderRepository.OrderRow, Long> idCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, Long> customerCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, Double> totalCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, String> dateCol;
    @FXML
    private TableColumn<OrderRepository.OrderRow, String> statusCol;

    private AppContext ctx;

    @FXML
    public void initialize() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        customerCol.setCellValueFactory(new PropertyValueFactory<>("userId"));
        totalCol.setCellValueFactory(new PropertyValueFactory<>("total"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("createdAt"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        refresh();
    }

    @FXML
    public void refresh() {
        if (ctx == null || ctx.currentUser == null) {
            System.err.println("Context not initialized");
            return;
        }

        try {
            long userId = ctx.currentUser.getId();
            List<OrderRepository.OrderRow> orders = ctx.orderService.listOrders(userId);
            ordersTable.getItems().setAll(orders);
            System.out.println("Orders loaded: " + orders.size());
        } catch (Exception e) {
            System.err.println("Error loading orders: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void cancelSelected() {
        OrderRepository.OrderRow selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            System.out.println("Select an order to cancel");
            return;
        }

        try {
            long userId = ctx.currentUser.getId();
            ctx.orderService.cancelOrder(userId, selected.getId());
            System.out.println("Order canceled: " + selected.getId());
            refresh();
        } catch (Exception e) {
            System.err.println("Error canceling order: " + e.getMessage());
        }
    }
}
