package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_Model.*;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.geometry.Insets;

import java.io.IOException;

public class ProductDetailsController implements UsesContext {
    @FXML
    private Label productNameLabel;
    @FXML
    private Label priceLabel;
    @FXML
    private Label descriptionLabel;
    @FXML
    private Label fullDescriptionLabel;
    @FXML
    private ImageView productImage;
    @FXML
    private Spinner<Integer> quantitySpinner;
    @FXML
    private VBox specsVBox;
    @FXML
    private Button buyButton;
    @FXML
    private TextField reviewTextField;
    @FXML
    private VBox reviewsVBox;

    private Product currentProduct;
    private AppContext ctx;
    private Runnable onGoBack;
    private MainController mainController;

    @FXML
    public void initialize() {
        SpinnerValueFactory<Integer> valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1);
        quantitySpinner.setValueFactory(valueFactory);
    }

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
    }

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    public void loadProduct(Product product) {
        this.currentProduct = product;
        productNameLabel.setText(product.getName());
        priceLabel.setText((long) product.getPrice() + " ₸");
        descriptionLabel.setText(product.getDescription());
        fullDescriptionLabel.setText(product.getDescription());

        if (product.getImagePath() != null && !product.getImagePath().isEmpty()) {
            try {
                Image image = new Image(product.getImagePath());
                productImage.setImage(image);
            } catch (Exception e) {
                System.out.println("Сурет табылмады: " + e.getMessage());
            }
        }

        loadSpecifications(product);
        quantitySpinner.getValueFactory().setValue(1);
    }

    private void loadSpecifications(Product product) {
        specsVBox.getChildren().clear();

        if (product instanceof Smartphone sp) {
            addSpecRow("Бренді", sp.getBrand());
            addSpecRow("Модель", sp.getModel());
            addSpecRow("Процессор", sp.getProcessor());
            addSpecRow("Дисплей", sp.getDisplayInches() + "\"");
            addSpecRow("Камера", sp.getCameraMegaPixel() + " МП");
            addSpecRow("Экран өлшемі", sp.getScreenRefreshRate() + " Hz");
            addSpecRow("ОС", sp.getOs());
            addSpecRow("ОЗУ", sp.getRamGB() + " GB");
            addSpecRow("Жад", sp.getRomGB() + " GB");
            addSpecRow("Батарея", sp.getBatteryCapacityMah() + " мАч");
            addSpecRow("Салмағы", sp.getWeightGrams() + " г");

        } else if (product instanceof Laptop laptop) {
            addSpecRow("Модель", laptop.getModel());
            addSpecRow("Процессор", laptop.getCpu());
            addSpecRow("ОЗУ", laptop.getRamGB() + " GB");
            addSpecRow("SSD", laptop.getSsdGB() + " GB");
            addSpecRow("Дисплей", laptop.getScreenInches() + "\"");
            addSpecRow("ОС", laptop.getOs());
        }
    }

    private void addSpecRow(String key, String value) {
        HBox row = new HBox();
        row.setSpacing(20);
        row.setPadding(new Insets(8, 0, 8, 0));
        row.setStyle("-fx-border-color: #f0f0f0; -fx-border-width: 0 0 1 0;");

        Label keyLabel = new Label(key);
        keyLabel.setPrefWidth(150);
        keyLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 12;");

        Label valueLabel = new Label(value);
        valueLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #333;");
        valueLabel.setWrapText(true);

        row.getChildren().addAll(keyLabel, valueLabel);
        specsVBox.getChildren().add(row);
    }

    @FXML
    public void addToCart() {
        if (currentProduct == null) {
            showAlert("Қате", "Өндік табылмады!");
            return;
        }

        int quantity = quantitySpinner.getValue();
        if (ctx != null) {
            for (int i = 0; i < quantity; i++) {
                ctx.cartService.add(currentProduct);
            }
        }

        showSuccess("✓ " + quantity + " x " + currentProduct.getName() + " сатып ал себесіне қосылды!");

        if (onGoBack != null) {
            onGoBack.run();
        }
    }

    @FXML
    public void addToFavorites() {
        if (currentProduct == null) return;
        showSuccess("♥ " + currentProduct.getName() + " добавлен в избранное!");
    }

    @FXML
    public void submitReview() {
        if (reviewTextField == null) return;
        String review = reviewTextField.getText().trim();
        if (review.isEmpty()) {
            showAlert("Қате", "Напишите отзыв!");
            return;
        }

        Label reviewLabel = new Label("👤 Вы: " + review);
        reviewLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #333; -fx-wrap-text: true;");
        reviewLabel.setWrapText(true);
        reviewsVBox.getChildren().add(0, reviewLabel);

        reviewTextField.clear();
        showSuccess("✓ Отзыв добавлен!");
    }

    @FXML
    public void goBack() {
        if (onGoBack != null) {
            onGoBack.run();
        }
    }

    public void setOnGoBack(Runnable callback) {
        this.onGoBack = callback;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("✓ Сәтті");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
