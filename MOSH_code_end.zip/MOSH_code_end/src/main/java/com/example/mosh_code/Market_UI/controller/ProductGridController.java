package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_Model.Product;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.ScrollPane;

import java.util.List;

public class ProductGridController implements UsesContext {
    @FXML
    private GridPane productGrid;

    private AppContext ctx;
    private Runnable onCartChanged;
    private MainController mainController;

    @FXML
    public void initialize() {
        System.out.println("ProductGridController initialized");
    }

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        loadAllProducts();
    }

    public void setOnCartChanged(Runnable r) {
        this.onCartChanged = r;
    }

    public void setMainController(MainController main) {
        this.mainController = main;
    }

    private void loadAllProducts() {
        if (ctx == null || productGrid == null) {
            System.err.println("Context or grid is null");
            return;
        }

        try {
            productGrid.getChildren().clear();
            List<Product> allProducts = ctx.shopService.getAllProducts();
            System.out.println("Loading " + allProducts.size() + " products");

            int col = 0;
            int row = 0;
            for (Product p : allProducts) {
                VBox card = card(p);
                productGrid.add(card, col, row);
                col++;
                if (col >= 3) {
                    col = 0;
                    row++;
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading products: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void showCategory(String categoryName) {
        if (ctx == null || productGrid == null) return;

        try {
            productGrid.getChildren().clear();
            List<Product> products = ctx.shopService.getProductsByCategoryName(categoryName);

            int col = 0;
            int row = 0;
            for (Product p : products) {
                VBox card = card(p);
                productGrid.add(card, col, row);
                col++;
                if (col >= 3) {
                    col = 0;
                    row++;
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading category: " + e.getMessage());
        }
    }

    public void showSearch(String query) {
        if (ctx == null || productGrid == null) return;

        try {
            productGrid.getChildren().clear();
            List<Product> results;
            if (query == null || query.isEmpty()) {
                results = ctx.shopService.getAllProducts();
            } else {
                results = ctx.shopService.search(query);
            }

            int col = 0;
            int row = 0;
            for (Product p : results) {
                VBox card = card(p);
                productGrid.add(card, col, row);
                col++;
                if (col >= 3) {
                    col = 0;
                    row++;
                }
            }
        } catch (Exception e) {
            System.err.println("Error searching products: " + e.getMessage());
        }
    }

    private VBox card(Product p) {
        VBox box = new VBox(8);
        box.setPrefWidth(240);
        box.setStyle("-fx-background-color: white; -fx-padding: 12; -fx-border-color: #E5E7EB; -fx-border-radius: 8;");

        Label name = new Label(p.getName());
        name.setStyle("-fx-font-weight: bold;");

        Label price = new Label((long) p.getPrice() + " T");
        price.setStyle("-fx-text-fill: #ff6b35; -fx-font-size: 14; -fx-font-weight: bold;");

        Label desc = new Label(p.getDescription());
        desc.setStyle("-fx-font-size: 10; -fx-text-fill: #666;");
        desc.setWrapText(true);

        Button detailsBtn = new Button("Details");
        detailsBtn.setPrefWidth(210);
        detailsBtn.setStyle(
                "-fx-padding: 8; " +
                        "-fx-background-color: #17a2b8; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 11; " +
                        "-fx-border-radius: 4;"
        );
        detailsBtn.setOnAction(e -> showProductDetails(p));

        box.getChildren().addAll(name, price, desc, detailsBtn);
        return box;
    }

    private void showProductDetails(Product product) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/com/example/mosh_code/view/pages/products_details.fxml")
            );
            ScrollPane detailsPage = loader.load();
            ProductDetailsController detailsCtrl = loader.getController();

            detailsCtrl.setContext(ctx);
            detailsCtrl.setMainController(mainController);
            detailsCtrl.loadProduct(product);

            detailsCtrl.setOnGoBack(() -> {
                loadAllProducts();
                if (onCartChanged != null) onCartChanged.run();
            });

            if (mainController != null) {
                mainController.showProductDetails(detailsPage);
            }
        } catch (Exception e) {
            System.err.println("Error loading product details: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
