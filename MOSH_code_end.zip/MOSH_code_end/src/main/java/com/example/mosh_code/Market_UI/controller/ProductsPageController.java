package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.HelloApplication;
import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.VBox;

import java.net.URL;

public class ProductsPageController implements UsesContext {

    @FXML private VBox vbox;

    private ProductGridController productGridController;
    private AppContext ctx;

    @FXML
    public void initialize() {
        try {
            URL url = HelloApplication.class.getResource(
                    "/com/example/mosh_code/view/parts/product_grid.fxml"
            );
            System.out.println("product_grid.fxml URL = " + url);

            if (url == null) {
                System.out.println("⚠ product_grid.fxml табылмады!");
                return;
            }

            FXMLLoader loader = new FXMLLoader(url);
            javafx.scene.control.ScrollPane gridPane = loader.load();
            productGridController = loader.getController();

            vbox.getChildren().clear();
            vbox.getChildren().add(gridPane);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ product_grid.fxml жүктеу: " + e.getMessage());
        }
    }

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        if (productGridController != null) {
            productGridController.setContext(ctx);
        }
    }

    public ProductGridController getProductGridController() {
        return productGridController;
    }
}
