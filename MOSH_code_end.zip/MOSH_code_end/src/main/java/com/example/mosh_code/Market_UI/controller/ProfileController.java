package com.example.mosh_code.Market_UI.controller;

import com.example.mosh_code.Market_UI.app.AppContext;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ProfileController implements UsesContext {
    @FXML
    private Label cardNumberLabel;
    @FXML
    private Label balanceLabel;

    private AppContext ctx;

    @Override
    public void setContext(AppContext ctx) {
        this.ctx = ctx;
        refresh();
    }

    @FXML
    public void refresh() {
        if (ctx == null || ctx.currentUser == null) return;

        long userId = ctx.currentUser.getId();
        String card = ctx.accountService.getCardNumber(userId);
        long bal = ctx.accountService.getBalance(userId);

        cardNumberLabel.setText("Card: " + card);
        balanceLabel.setText("Balance: " + bal + " ₸");
    }
}


