package com.example.mosh_code.Market_UI.controller;

import javafx.fxml.FXML;

public class SidebarController {
    private MainController mainController;

    public void setMainController(MainController main) {
        this.mainController = main;
    }

    @FXML
    public void showProducts() {
        if (mainController != null) {
            mainController.showProducts();
        }
    }

    @FXML
    public void showOrders() {
        if (mainController != null) {
            mainController.showOrders();
        }
    }

    @FXML
    public void showCheckout() {
        if (mainController != null) {
            mainController.showCheckout();
        }
    }

    @FXML
    public void showProfile() {
        if (mainController != null) {
            mainController.showProfile();
        }
    }
}



